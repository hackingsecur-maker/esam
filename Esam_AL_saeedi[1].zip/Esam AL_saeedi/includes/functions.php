<?php
// بدء الجلسة بطريقة متوافقة مع الإصدارات القديمة
if (version_compare(PHP_VERSION, '5.4.0', '>=')) {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
} else {
    if (session_id() == '') {
        session_start();
    }
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}

function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        header("Location: home.php");
        exit();
    }
}

function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// دالة لإنشاء hash باستخدام crypt مع salt
function createHash($password) {
    // إنشاء salt بشكل آمن
    $salt = '';
    $chars = './0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    for ($i = 0; $i < 22; $i++) {
        $salt .= $chars[mt_rand(0, 63)];
    }
    $salt = '$2y$10$' . $salt;
    return crypt($password, $salt);
}

// دالة للتحقق من كلمة المرور
function verifyHash($password, $hashed_password) {
    // استخدام crypt للتحقق
    return crypt($password, $hashed_password) === $hashed_password;
}
?>